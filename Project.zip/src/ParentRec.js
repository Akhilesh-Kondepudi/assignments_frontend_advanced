import ChildRes from "./ChildRec";
import Data from "./data";
function ParentRes(){
   var arr = Data();
    var result = arr.map(item=>
        {
            return <ChildRes obj={item}/>
    })
    return(
        <>
        <br/><br/>
        <div className="row border border-dark border-2 col-sm-12">
            {result}
        </div>
        </>
    )
}

export default ParentRes;