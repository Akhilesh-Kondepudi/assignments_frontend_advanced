import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import ParentRes from './ParentRec';
import ChildRes from './ChildRec';
import Login from './Login';
import {Route, Routes, Link, BrowserRouter as Router} from 'react-router-dom'
import Employees from './Employees';
import Details from './Details';
import Home  from './Home';
import RecDetails from './RecDetails';
import Logout from './Logout';
const routing = (
  <div style={{textAlign:"center"}}>
    <h1>Website Project</h1>
    <Router>
      <Link to="/">Home</Link> |  
      <Link to="/Emp">Employees</Link> | 
      <Link to="/Rec">Recipies</Link> |
      <Link to="/Login">Login</Link> |
      <Link to="/Logout">Logout</Link> 
      

      <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/Login" element={<Login/>}/>
        <Route path="/Emp" element={<Employees/>}/>
        <Route path="/Details/:id" element={<Details/>}/>
        <Route path="/Rec" element={<ParentRes/>}/>
        <Route path="/RecDet/:recname" element={<RecDetails/>}/>
        <Route path="/Logout" element={<Logout/>}/>
      </Routes>

    </Router>  
  </div>
)

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {routing}
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
