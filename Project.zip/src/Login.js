import { useState } from "react";
import {useNavigate} from "react-router-dom";

function Login(){

    let [uid,setUid] = useState("");
    let [pwd,setPwd] = useState("");
    let [res,setRes] = useState("");
    let navigate = useNavigate();
    //let token = false;

    function uidChange(event){
        setUid(event.target.value)
    }

    function pwdChange(event){
        setPwd(event.target.value)
    }

    function validation(){
        if(uid=="admin" && pwd=="admin123"){
            setRes("Welcome to Admin");
            sessionStorage.setItem("token",true);
            navigate(`/`);
        }
        else{
            setRes("Invalid username or password");
        }
    }
    return(
        <div className="text-center mt-3">
            <h1 className="p-2 mb-0 border-2 border-start border-end border-top border-dark " style={{backgroundColor:"rgb(253,225,189)"}}>Login for Premium Members</h1>
            <div className="mt-0" style={{backgroundColor:"rgb(253,225,189)",border:"2px solid black"}}>
                <br/>
                <span>Username : </span>
                <input type="text" onChange={uidChange}/>
                <br/>
                <br/>
                <span>Password : </span>  
                <input type="password" onChange={pwdChange}/>      
                <br/><br/>
            </div>
            <br/>
            <button type="button" onClick={validation}>Login</button>
            <br/><br/>
            <span style={{color:"red"}}>{res}</span>
        </div>
    )
}

export default Login;