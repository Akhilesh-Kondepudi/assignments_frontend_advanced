import {Link,useParams} from 'react-router-dom';

function ChildRes(props){
    const {recname} = useParams();
    return(
        <div style={{overflow: "auto",float:"left",textAlign:"center",backgroundColor:"rgb(253,225,189)"}} className = "col-sm-4 ps-4">
            <br/>
            <Link to={"/RecDet/" + props.obj.name}><img style={{height: "40%", width: "90%"}} src = {props.obj.link}/></Link>
            <br/><br/>
            <Link style={{textDecoration:"none"}} className="fw-bold text-dark" to={"/RecDet/" + props.obj.name}>{props.obj.title}</Link>
            <p style={{textAlign:"justify",paddingTop: "16px"}}>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis, delectus dolorum. Doloribus et quibusdam cumque totam numquam quod in earum.</p>
            <button className="btn btn-light" type="button">
                <Link style={{color: "black",textDecoration:"none"}} to={"/RecDet/" + props.obj.name}>Know More</Link>
            </button>
        </div>
    )
}

export default ChildRes;