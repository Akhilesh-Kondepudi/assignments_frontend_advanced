function Data()

{
    var data = [
    {link:"https://merryboosters.com/wp-content/uploads/2018/02/Screen-Shot-2018-02-21-at-4.19.17-PM.png",title:"Swiss Roll Slices",name:"SwissRoll"},
    {link:"https://th.bing.com/th/id/OIP._pkYwoD8SAWUUaNf_sXGbgHaE2?pid=ImgDet&rs=1",title:"Lemon Pasta",name:"LemonPasta"},
    {link:"https://th.bing.com/th/id/OIP.jeF2Xs-XHsoYVHwwmNElMQHaFU?pid=ImgDet&rs=1",title:"Salad With Tomatoes",name:"Salad"},
    {link:"https://merryboosters.com/wp-content/uploads/2018/02/Screen-Shot-2018-02-21-at-4.19.17-PM.png",title:"Swiss Roll Slices",title:"Swiss Roll Slices",name:"SwissRoll"},
    {link:"https://th.bing.com/th/id/OIP._pkYwoD8SAWUUaNf_sXGbgHaE2?pid=ImgDet&rs=1",title:"Lemon Pasta",name:"LemonPasta"},
    {link:"https://merryboosters.com/wp-content/uploads/2018/02/Screen-Shot-2018-02-21-at-4.19.17-PM.png",title:"Salad With Tomatoes",name:"Salad"},
];


return  data;
}

export default Data;
