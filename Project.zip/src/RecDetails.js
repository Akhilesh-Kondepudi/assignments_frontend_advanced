import {Link, useParams} from 'react-router-dom';
import Data from "./data";

function RecDetails(props){
    var arr = Data();
    const {recname} = useParams();
    console.log(recname);
    var obj = arr.find(item => item.name == recname)
    return(
        <>
            <br/><br/>
            <div className="container-fluid row m-0 p-0" style={{backgroundColor:"rgb(253,225,189)"}}>
                <div style={{borderTop: "2px solid black", borderLeft: "2px solid black", borderBottom: "2px solid black"}} className="col-sm-12">
                    <div>
                        <img style={{paddingLeft: "50px", paddingTop: "40px", height:"80%", width:"90%"}} src = {obj.link} />
                        <br/><br/>
                        <p style={{textAlign:"center", fontWeight:"bold"}}>{obj.title}</p>
                        <p style={{textAlign: "justify"}}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, odit, totam omnis necessitatibus ratione nostrum vitae non iusto explicabo inventore in delectus aut, nesciunt fugit! Possimus dignissimos in accusamus, nemo molestias asperiores nobis eligendi, fugit quasi facilis ut ipsa voluptatum. Delectus obcaecati minima atque harum quisquam provident tenetur aut odio explicabo commodi facere aliquid itaque dolorum accusantium enim, sunt in quis. Debitis non sunt fugit doloribus velit ipsa ullam nostrum ipsam labore quisquam eos pariatur aspernatur consequuntur ducimus laudantium totam nulla laborum voluptatum dolorum, est maxime tenetur omnis, commodi at? Eveniet, quidem. Adipisci veritatis sapiente nisi deleniti aliquam, velit maiores ex repellendus ea ducimus praesentium tenetur! Hic obcaecati voluptatum doloribus placeat! Maiores optio repellat sint expedita quasi sequi maxime enim assumenda, quibusdam molestiae, cupiditate itaque possimus. Harum necessitatibus ipsam suscipit nostrum magnam dolor accusamus velit asperiores, placeat rerum consectetur soluta, voluptatum consequatur perferendis nulla provident nisi iure dolorum doloremque obcaecati beatae possimus laborum vel. Dolorem eius nesciunt voluptatibus error ex? Aperiam dolorem consequatur autem quos maxime numquam saepe quis voluptate. Exercitationem quae ratione accusantium, inventore dolorem placeat quidem ad iusto amet sunt, perferendis sequi suscipit error alias id beatae voluptatibus aliquam aperiam. Hic quidem architecto modi laboriosam totam illum ipsum.</p>
                    </div>
                </div>
            </div>
        </>
    )
}
 
export default RecDetails;