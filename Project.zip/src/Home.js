function Home(){
    return(
        <>
        <br/><br/>
            <div className="row border border-dark border-3 m-2 p-4" style={{backgroundColor:"rgb(253,225,189)"}}>
                <div className="col-sm-3">
                    <img src="redlogo.png" width="110px"/>
                </div>
                <div className="col-sm-9">
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Omnis, modi ratione cupiditate accusamus aliquam itaque, ipsum numquam cum aspernatur obcaecati, ipsam dolorum? Amet, possimus. Optio, in blanditiis ut itaque dicta fugit eius quos, ea, consectetur fuga cupiditate? Saepe laboriosam non quod iste repellendus unde suscipit. Quidem qui reiciendis laudantium ut?</p>
                </div>
            </div>
        </>
    )
}

export default Home;