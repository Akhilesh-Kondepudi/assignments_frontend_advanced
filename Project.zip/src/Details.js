import {Link, useParams} from 'react-router-dom';

function Details(props){
    var arr = [
                
        {
          "empno": 1,
          "ename": "Akhil",
          "deptno": 10,
          "job": "CEO"
        },
        {
          "empno": 2,
          "ename": "Tom",
          "deptno": 20,
          "job": "Lead"
        },
        {
          "empno": 3,
          "ename": "Jerry",
          "deptno": 30,
          "job": "Analyst"
        },
        {
          "empno": 4,
          "ename": "Ben10",
          "deptno": 40,
          "job": "Manager"
        },
        {
          "empno": 5,
          "ename": "Mr Bean",
          "deptno": 50,
          "job": "Analyst"
        },
        {
          "ename": "Scott",
          "deptno": "60",
          "job": "Analyst",
          "empno": 6
        }     
    ];


    const {id} = useParams();
    var obj = arr.find(item => item.empno == id);
    return(
        <>
            <br/><br/>
            <div style={{backgroundColor:"rgb(253,225,189)",border:"2px solid black"}}>
                <br/>
                Emp No : {obj.empno}<br/>
                Emp Name : {obj.ename}<br/>
                Deptno  : {obj.deptno}<br/>
                Emp Job : {obj.job}<br/><br/>
            </div>
        </>
    )
}

export default Details;