import {useState} from "react";
import {Link} from 'react-router-dom';
function Employees()
{

    var [data,setData] = useState([]);
    var [empno,setEmpno] = useState("");
    var [ename,setEname] = useState("");
    var [deptno,setDeptno] = useState("");
    var [job,setJob] = useState("");


    function getData(){
        setData(
            [
                
                {
                  "empno": 1,
                  "ename": "Akhil",
                  "deptno": 10,
                  "job": "CEO"
                },
                {
                  "empno": 2,
                  "ename": "Tom",
                  "deptno": 20,
                  "job": "Lead"
                },
                {
                  "empno": 3,
                  "ename": "Jerry",
                  "deptno": 30,
                  "job": "Analyst"
                },
                {
                  "empno": 4,
                  "ename": "Ben10",
                  "deptno": 40,
                  "job": "Manager"
                },
                {
                  "empno": 5,
                  "ename": "Mr Bean",
                  "deptno": 50,
                  "job": "Analyst"
                },
                {
                  "ename": "Scott",
                  "deptno": "60",
                  "job": "Analyst",
                  "empno": 6
                }     
            ]
        );
    }

    function addData()
    {
        let empObj = {};
        empObj.empno = empno;
        empObj.ename = ename;
        empObj.deptno = deptno;
        empObj.job = job;
        let tempArray = Object.assign([], data);
        tempArray.push(empObj);     
        setData( tempArray );
    }

    function updateData()
    { 
        let tempArray = Object.assign([], data);
        let obj = tempArray.find(item=>item.empno == empno);
        obj.empno = empno;
        obj.ename = ename;
        obj.deptno = deptno;
        obj.job = job;
        setData( tempArray );
    }

    var result = data.map((item,index) =>
    {
        return <tr>
            <td>{item.empno}</td>
            <td>{item.ename}</td>
            <td>{item.deptno}</td>
            <td>{item.job}</td>
            <td>
                <Link to={"/Details/" + item.empno}>Select</Link> 
            </td>
        </tr>
    })

    if(sessionStorage.getItem("token")){
    return(
        <div className="mt-3 border border-3 border-dark" style={{backgroundColor:"rgb(253,225,189)"}}>
            <h1>CRUD on Emp Data</h1>
            <hr/>
            <br/>
            <input value={empno} type="text" placeholder="Enter Empno" onChange={(e)=>setEmpno(e.target.value)}/>
            <input value={ename} type="text" placeholder="Enter Emp Name" onChange={(e)=>setEname(e.target.value)}/>
            <input value={deptno} type="text" placeholder="Enter Dept No" onChange={(e)=>setDeptno(e.target.value)}/>
            <input value={job} type="text" placeholder="Enter Job" onChange={(e)=>setJob(e.target.value)}/>
            <br/><br/>
            <input type="button" value="Get Data" onClick={getData}/>
            <input type="button" value="Add Data" onClick={addData}/>
            <input type="button" value="Update Data" onClick={updateData}/>
            <br/><br/>
            <table border="2" className="table">
                <tr>
                    <th>Empno</th>
                    <th>Emp Name</th>
                    <th>Deptno</th>
                    <th>Job</th>
                </tr>
                {result}
            </table>
        </div>
    )}
    else{
        return(
        <>
            <br/><br/>
            <div style={{backgroundColor:"rgb(253,225,189)",padding:"20px"}}>
            <h1>You are not authorized</h1>
            <h3>Login to view this page</h3>
            <Link to="/Login">Login</Link>
            </div>
        </>
        )
    }
}

export default Employees;