
function Logout(){
    sessionStorage.removeItem("token");
    return(
        <>  
            <br/><br/>
            <h3 style={{backgroundColor:"rgb(253,225,189)",padding:"20px"}}>You have been Logged Out</h3>
        </>
    )
}

export default Logout;